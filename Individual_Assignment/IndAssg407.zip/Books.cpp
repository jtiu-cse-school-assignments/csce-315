/*
The stuff needed is input error handling for each funciton

 */
#include <iostream>
#include <cmath>
#include <stdlib.h>
#include <iomanip>
#include <sstream>


#include "books.h"

using namespace std;

Book::Book(){
	isbn = new std::string("");
	cost = new std::string("");
	title = new std::string("");
	author = new std::string("");
	edition = new std::string("");
	pubDate = new std::string("");
	condition = new std::string("");

}
Book::~Book(){
	delete isbn;
	delete cost;
	delete title;
	delete author;
	delete edition;
	delete pubDate;
	delete condition;
}

void Book::add_isbn(std::string isbnUser){
	std::string tempIsbn =isbnUser;
	if(tempIsbn.size() == 13){
		
		isbn = new std::string(tempIsbn);
	}
	else{
	//Call function to handle error so that user can input a correct command line
		std::cout<<"The isbn number was typed incorrectly!Please try again\n";
	}
//	std::cout<<*isbn;
}

void Book::add_cost(std::string costUser){
	//The following functionality is precision handling for the floating cost value of the book to 2 places after the decimal
	std::string tempCost = costUser;
	float costAsFloat = std::stof(tempCost);
	std::stringstream ss;
	ss<<fixed<<setprecision(2)<<costAsFloat;
	tempCost =ss.str();
	cost = new std::string(tempCost);

}

void Book::add_title(std::string titleUser){
	//Important thing to note is title is at the end of the command so conditions should be met in the courseDatabase
	title = new std::string(titleUser);
//	cout<<*title;
}

void Book::add_author(std::string authorUser){
	author =new std::string(authorUser);
//	cout<<*author;
}

void Book::add_edition(std::string editionUser){
	//conditions so that edition is set to + int value
	std::string tempEdition = editionUser;
	int tempEditionVal = std::stoi(tempEdition);
	if(tempEditionVal<=0){
		std::cout<<"Please type appropriate edition...";
	}
	else{
		edition = new std::string(tempEdition);	
	}
}

void Book::add_pubDate(std::string pubDateUser){
	//Parese the date for MM and YYYY and check if they meet conditions using a delimiter
	std::string tempPubDate = pubDateUser;

	if(tempPubDate.size()== 7){
		std::string delimiter = "/";
		std::string mmToken =tempPubDate.substr(0,tempPubDate.find(delimiter));
		std::string yyyyToken = tempPubDate.substr(tempPubDate.find(delimiter)+1,std::string::npos);
		int month = std::stoi(mmToken);
		int year = std::stoi(yyyyToken);

		if((month>=0 && month<13) && (year<2017 && year>1900)){
			pubDate = new std::string(tempPubDate);
			cout<<pubDate;
		}	
		else{
			std::cout<<"Please type in the pubDate correctly...";
		}					
	}
	else{
		std::cout<<"Please type in a correct publication date...\n";
	}
}
void Book::add_condition(std::string conditionUser){
	std::string tempCondition = conditionUser;
	if(tempCondition == "N" || tempCondition == "U" || tempCondition == "R" || tempCondition == "E"){
		condition = new std::string(tempCondition);
		cout<<*condition;
	}
	else{
		std::cout<<"Please type in the correct condition of the book. (i.e. N,U,R,or E)";
	}
}

std::string Book::get_isbn(){
	std::string tempIsbn = *isbn;
	return tempIsbn;
}

void Book::showInfo(){
	std::string bookInfo;
	bookInfo = *isbn + "  "+ *title + " "+  *author +" " + *edition +" "+ *condition +" "+ *cost +" "+*pubDate;
	cout<<bookInfo<<"\n";
	cout<<*title<<*author<<"\n";
}
std::string Book::getPubDate(){
	std::string tempPubDate = *pubDate;
	return tempPubDate;
}
std::string Book::getCost(){
	std::string tempCost = *cost;
	return tempCost;
}
