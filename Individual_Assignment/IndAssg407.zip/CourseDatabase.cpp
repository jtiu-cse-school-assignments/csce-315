#include <iostream>
#include <vector>
#include <sstream>
#include <string>
#include "CourseDatabase.h"

using namespace std;

CourseDatabase::CourseDatabase() : books(std::vector<Book>()) , classes(std::vector<Course>()){} 

CourseDatabase::~CourseDatabase(){ 
	//Clear books and class vecotors so that we can instantiate a new CourseDataBase if need be
	books.clear();
	classes.clear();	
}

void CourseDatabase::executeCommand(std::string userInput){
	std::string tempInput = userInput;
	std::vector<std::string> input;
	std::stringstream parse(tempInput);

	while(parse>>tempInput){
		input.push_back(tempInput);
	}

	//conversion from string to char must occur next
	int x = 0;// iterator for books class
	int y = 0; //iterator for courses class
	
	string charCommand = input.at(0);
	bool isInputCorrect = true;

	while(isInputCorrect == true){
		if(charCommand == "B"){
			Book tempAdd; 
			books.push_back(tempAdd);
			books.at(x).add_isbn(input.at(1));
			books.at(x).add_title(input.at(2));
			books.at(x).showInfo();
			x+=1;
		}
		else if(charCommand == "D"){
			int it =0;
			while(books.at(it).get_isbn() != input.at(1)){
				++it;
			}
			if(input.at(it) == "A"){
				books.at(x).add_author(input.at(3));
			}
			else if(input.at(2) == "E"){
				books.at(x).add_edition(input.at(3));
			}
			else if(input.at(2) == "D"){
				books.at(x).add_pubDate(input.at(3));
			}
			else{
				cerr<<"Sorry try a different input\n";
			}
			x+=1;
		}	
			//Given ISBN from user, add author(A),edition(E), or Publication date(D)
		else if(charCommand == "M"){
			   int it2 =0;
                        while(books.at(it2).get_isbn() != input.at(1)){
                                ++it2;
                        }
                        
			books.at(x).add_cost(input.at(2));
			books.at(x).add_edition(input.at(2));
			x+=1;
		}
			//Given ISBN, determine the cost of `the book as a double type and the condition of the book
		else if(charCommand == "C"){
			classes.at(y).add_deptCode(input.at(1));
			classes.at(y).add_courseNumber(input.at(2));
			classes.at(y).add_courseName(input.at(3));
			y+=1;
		}
			//Define a course with a 4-letter dept code, a 3 digit course number, and name of the course
		else if(charCommand == "A"){
			int it3 =0;
                          while(books.at(it3).get_isbn() !=input.at(1)){
                                  ++it3;
                         }
			  int itCode =0; //iterator for deptCode
			while(classes.at(itCode).get_deptCode() != input.at(2)){
				++itCode;
			}
			int itCourseNum =0;
			while(classes.at(itCourseNum).get_courseNum()!= input.at(3)){
				++itCourseNum;
			}
			if(itCode == itCourseNum){
				classes.at(y).add_book(books.at(itCode));
				classes.at(y).add_sectionNum(input.at(4));
				classes.at(y).add_req(input.at(5));
			}
			else{
			 cerr<<"Oops try again!\n";	
			}

		}
				//assign book to class
				//
		else if(charCommand == "GC"){
			 int itCode2 =0; //iterator for deptCode
                          while(classes.at(itCode2).get_deptCode() != input.at(1)){
                                  ++itCode2;
                          }
                          int itCourseNum2= 0;
                          while(classes.at(itCourseNum2).get_courseNum()!= input.at(2)){
                                  ++itCourseNum2;
                          }
			  if(itCourseNum2 == itCode2){
			 	 Course bookList = classes.at(itCode2);
				 std::vector<Book> list =bookList.get_bookList();
				for(int k = 0; k<list.size();++k){
					list.at(k).showInfo();
				}
				
			 }
			  else{
				cerr<<"Oops seems like you typed incorrectly!\n";
			  }
		}
		else if(charCommand == "GS"){
                          int itCode3 =0; //iterator for deptCode
			  while(classes.at(itCode3).get_deptCode() != input.at(1)){
				  ++itCode3;
                           }
                           int itCourseNum3= 0;
                           while(classes.at(itCourseNum3).get_courseNum()!= input.at(2)){
                                   ++itCourseNum3;
                           }
			   int itSection = 0;
			   while (classes.at(itSection).get_section()!= input.at(3)){
				++itSection;
			   }
                           if(itCode3 == itSection){
                           Course bookList2 = classes.at(itCode3);
                           vector<Book> list2 = bookList2.get_bookList();
			   for(int j =0;j<list2.size();++j){
				   list2.at(j).showInfo(); 
                          }
			   }
			   else{
                                cerr<<"Oops seems like you typed incorrectly!\n";
                          }
	
		}
		else if(charCommand == "GB"){
			int it3 =0;
                          while(books.at(it3).get_isbn() !=input.at(1)){
                                  ++it3;
                         }
			 books.at(it3).showInfo();
		}
		else if(charCommand == "PB"){
			int its =0;
			while(!books.empty()){
				books.at(its).showInfo();
			}	++its;
		}	
		else if(charCommand == "PC"){
			int its2=0;
			while(!classes.empty()){
				cout<<classes.at(its2).showCourseInfo();
			}	
		}
		else if(charCommand == "PY"){
			std::vector<Book> samePubDates;
			while(!books.empty()){
				for(int its3 = 0;books.at(its3).getPubDate() != input.at(1);++its3){
					samePubDates.push_back(books.at(its3));
				}
				for(int p = 0;p<samePubDates.size();++p){
					samePubDates.at(p).showInfo();
				}
				samePubDates.clear();
			}
		}
		else if(charCommand == "PD"){
			  std::vector<Book> sameDept;
                          while(!books.empty()){                          
				for(int its4 =0;classes.at(its4).get_deptCode() !=input.at(1);++its4){
                                 	 sameDept.push_back(classes.at(its4).get_bookList().at(its4));
                          	}
                          	for(int i =0;i<sameDept.size();++i){        
                                	 sameDept.at(i).showInfo();
                          	}
				sameDept.clear();
			  }
		}
		else if(charCommand == "PM"){
			std::vector<Book> sameDeptTemp;	 
			std::vector<float> booksCost;
			float min = 0.00;
			float max = 0.00;
			float sumMin = 0.00;
			float sumMax = 0.00;
			float avgMin = 0.00;
			float avgMax = 0.00;
			bool booksDeptCheck = true;
			while(booksDeptCheck == true){
			       	for(int costIt =0;classes.at(costIt).get_deptCode() !=input.at(1);++costIt){
					sameDeptTemp.push_back(classes.at(costIt).get_bookList().at(costIt));
				}
				if(!sameDeptTemp.empty()){
					for(int costIt2 = 0; costIt2<sameDeptTemp.size();++costIt2){
						booksCost.push_back(std::stof(sameDeptTemp.at(costIt2).getCost()));
					}
					for(int minIt = 0; minIt<booksCost.size()-1;++minIt){
						if(booksCost.at(minIt) < booksCost.at(minIt+1)){
							min = booksCost.at(minIt);
							max = booksCost.at(minIt +1);
						}
						else{
							min = booksCost.at(minIt + 1);
							max = booksCost.at(minIt);
						}
						sumMin+=min;
						sumMax+=max;
					}
				}
				else{
					std::cout<<"No books listed for this dept, try again\n";
					booksDeptCheck = false;
				}	
				avgMin =min/(booksCost.size()-1);
				avgMax =max/(booksCost.size()-1);
				std::cout<<"The MinAvg: "<<avgMin<<"  The MaxAvg: "<<avgMax<<"\n";
				booksCost.clear();
			}
		}		
		else{
			std::string userInput;
			std::cout<<"Seems like you typed something incorrectly"<<"\n"<<"Would you like to exit or continue?Type 'e' to exit or 'c' to continue\n";
			std::cin>>userInput;
			while(userInput == "r" && userInput != "c"){
				std::cout<<"Try a different input\n";
			}
			if(userInput == "e"){
				isInputCorrect = false;
				std::cout<<"Exiting....\n";
			}
			if(userInput == "c"){
				cout<<"Ok, please try a different command\n";
			}	
		}
		 isInputCorrect = false;
	}

}

