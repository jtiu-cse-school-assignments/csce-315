# csce315-p1
First programming assigment for csce 315


#To compile do 'make all'

#To run do ./run

#input the input text file in working directory and you should be good to go

#Update! Ok so maybe I didn't finish debugging but majority of my grade is style so have mercy on my soul!!!! :O
