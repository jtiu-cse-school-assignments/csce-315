#include <iostream>
#include <string> 
#include <fstream>
#include "CourseDatabase.h"

using namespace std;

int main(){
	std::string inputFileName;
	cout<<"Please type in the file that contains a command list with a .txt file\n";
	cin>>inputFileName;
	bool isCommandCorrect = true;

	ifstream inputFile; // input file to be read
	
	CourseDatabase Database;
	string newCommand;
	inputFile.open(inputFileName);
	if(inputFile.fail()){
		cerr<<"Invalid file,try again\n";
	}	
	else{
		while(!inputFile.eof()){
			getline(inputFile,newCommand);
			Database.executeCommand(newCommand);
		}
		inputFile.close();
		Database.~CourseDatabase();
		system("pause"); 
		}
	return 0;
}
