#ifndef CourseDatabase_h
#define CourseDatabase_h

#include <iostream>
#include <vector>
#include <queue>

#include <string>
#include "books.h"
#include "courses.h"


class CourseDatabase{ 
	//Database consists of a groups of books that are sets of classes
        std::vector<Book> books;      
        std::vector<Course> classes;
	public:
		CourseDatabase();
		~CourseDatabase();		
		void executeCommand(std::string command);
	
};

#endif
