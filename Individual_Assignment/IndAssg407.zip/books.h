#ifndef book_h
#define book_h

#include <iostream>
#include <string>

class Book{
	public:
		Book();
		~Book();
		void add_isbn(std::string givenIsbn);
		void add_cost(std::string givenCost);
		void add_title(std::string givenTitle);
		void add_author(std::string givenAuthor);
		void add_edition(std::string givenEd);
		void add_pubDate(std::string givenDate);
		void add_condition(std::string givenCond);
		std::string get_isbn();
		void showInfo();
		std::string getCost();
		std::string getPubDate();
	private:
		std::string* isbn;
		std::string* cost;
		std::string* title;
		std::string* author;
		std::string* edition;
       		std::string* pubDate; //Publication date
	       	std::string* condition;
};

#endif
