#ifndef courses_h
#define courses_h


#include <iostream>
#include <string>
#include <vector>
#include "books.h"

class Course{
	public:
		Course();
		~Course();
		void add_deptCode(std::string givenCode);
		void add_courseNumber(std::string givenNumber);
		int get_newNumBooks();
		void add_courseName(std::string givenName);
		void add_bookIsbn(std::string isbnGiven);
		void add_sectionNum(std::string sectionGiven);
		void add_req(std::string givenReq);
		void add_book(Book givenBook);
		std::string showCourseInfo();
		std::string get_deptCode();
		std::string get_courseNum();
		std::string get_section();
		std::vector<Book> get_bookList();
	private:
		std::string* code;
		std::string* number;
		std::string* name;
		std::string* bookIsbn;
		std::string* section;
		std::string* requisite; //is book required?
		int* numBooks; //Keeps track of size of vector 
		std::vector<Book> classBooks;
		};

#endif
