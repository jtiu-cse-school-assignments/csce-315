#include <iostream>
#include <stdlib.h>
#include <stdexcept>

//#include 
#include "courses.h"
using namespace std;

Course::Course(){
	numBooks = new int(0);// size of vector Books
	code = new std::string("");
	number =new std::string("");
	name = new std::string("");
	bookIsbn = new std::string("");
	section = new std::string("");
	requisite = new std::string("");
}

Course::~Course(){
	delete code;
	delete number;
	delete name;
	delete bookIsbn;
	delete section;
	delete requisite;
	classBooks.clear();
}

void Course::add_deptCode(std::string userCode){
	std::string tempUserCode = userCode;

	if(tempUserCode.size() == 4){
		code = new std::string(tempUserCode);
		cout<<*code;
	}
	else{
		cout<<"Whoops! It seems that your input is incorrect! The dept. code is of size 4\n";	
	}

}
void Course::add_courseNumber(std::string userNumber){
	std::string tempUserNumber = userNumber;

	if(tempUserNumber.size() == 3){
		number = new std::string(tempUserNumber);
	//	cout<<*number;	
	}
	else{
		cout<<"Whoops! It seems that your input is incorrect! The course number is of size 3\n";
	}
}
void Course::add_courseName(std::string userCourseName){
	std::string tempCourseName = userCourseName;
	name = new std::string(tempCourseName);
	cout<<*name;
}

void Course::add_bookIsbn(std::string userIsbn){
	std::string tempUserIsbn = userIsbn;
	if(tempUserIsbn.size()==13){
		bookIsbn = new std::string(tempUserIsbn);
	}
	else{
		cerr<<"Input is incorrect. Try again\n";
	}
}

void Course::add_sectionNum(std::string userSectionNum){
	std::string tempSectionNum = userSectionNum;
	if(tempSectionNum.size() == 3){
		section = new std::string(tempSectionNum);
	}
	else{
		cerr<<"Input is incorrect. Try again\n";
	}
}

void Course::add_req(std::string userReq){
	std::string tempUserReq = userReq;
	if(tempUserReq == "R"){
		requisite =new std::string(tempUserReq);
	}
	else if(tempUserReq == "O"){
		requisite = new std::string(tempUserReq);
	}
	else{
		cerr<<"User input is incorrect.Try again\n";
	}

}
void Course::add_book(Book bookAdd){
	classBooks.push_back(bookAdd);
}

std::string Course::get_deptCode(){
	std::string tempCode = *code;
	return tempCode;
}
std::string Course::get_courseNum(){
	std::string tempCourseNum = *number;
	return tempCourseNum;
}

std::vector<Book> Course::get_bookList(){
	return classBooks;
}

std::string Course::get_section(){
	std::string tempSection = *section;
	return tempSection;
}
int Course::get_newNumBooks(){
	vector<Book> tempBooks = classBooks;
	int numBook =0;
	for(std::vector<Book>::size_type i =0; i<tempBooks.size();++i){
		++numBook;
	}
	return numBook;
}
std::string Course::showCourseInfo(){
	std::string tempCourseInfo = *code + *number + *name + *section + *bookIsbn + *requisite;
	return tempCourseInfo;
}
