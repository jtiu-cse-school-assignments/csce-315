To compile, run the command “make”
To run the program, run the command “./main < input.txt”