//
//  Section.hpp
//  Individual Project
//


#ifndef Section_hpp
#define Section_hpp

#include <stdio.h>
#include <utility>
#include <string>
#include <vector>

//collection of a book to see whether or not they're required
struct section {
    std::vector<std::pair<std::string, std::string> > books;
};
#endif /* Section_hpp */
