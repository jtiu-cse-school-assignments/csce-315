//
//  Class.hpp
//  Individual Project
//


#ifndef Class_hpp
#define Class_hpp

#include <stdio.h>
#include <map>
#include <string>
#include <utility>
#include "Section.h"
using namespace std;

//defining the class, Class
class Class {
private:
    string name;
    map<string, section*> sections;
public:
    Class();
    string getName();
    void setName(string name);
    vector<pair<string, string> > getBooks(string section_num);
    void assignBook(string section_num, string isbn, string requirement);
    map<string, section*> getSections();
};
#endif /* Class_hpp */
