//
//  Book.cpp
//  Individual Project
//


#include "Book.h"

Book::Book() {

}


string Book::getInfo(string key) {
    return data[key];
}

void Book::setInfo(string key, string val) {
    data[key] = val;
}


//print all data associated with a book
void Book::print() {
    printInfo("title");
    printInfo("author");
    printInfo("edition");
    printInfo("month");
    printInfo("year");
    printInfo("new");
    printInfo("used");
    printInfo("rented");
    printInfo("electronic");
    cout << endl;
}


//print all information associated with a book (month, year, publication)
void Book::printInfo(string key) {
    string info = data[key];
    
    if (info != "") {
        if (key == "month")
            cout << "published: " << info << "/";
        else if (key != "year")
            cout << key << ": " << info << " ";
        else
            cout << info << " ";
    }
}

//returns lowest price of the cost of the cheapest version of a required book for a section.
double Book::getLowestPrice() {
    return lowest_price;
}

//sets the lowest price
void Book::setLowestPrice(double price) {
    lowest_price = price;
}

//returns highest price of the cost of the cheapest version of a required book for a section.
double Book::getHighestPrice() {
    return highest_price;
}

//sets highest price
void Book::setHighestPrice(double price) {
    highest_price = price;
}
