//
//  Class.cpp
//  Individual Project
//
//

#include "Class.h"

//constructor
Class::Class() {
}

string Class::getName() {
    return this->name;
}

//sets the name of the class
void Class::setName(string name) {
    this->name = name;
}

//gets the books for each section of a class
vector<pair<string, string> > Class::getBooks(string section_num) {
    section* my_section = sections[section_num];
    
    return my_section->books;
}

//assigns books for each section of a class
void Class::assignBook(string section_num, string isbn, string requirement) {
    section* my_section = sections[section_num];
    if (my_section == NULL) {
        sections[section_num] = new section;
        my_section = sections[section_num];
    }
    my_section->books.push_back(pair<string, string> (isbn, requirement));
}

//returns all sections for a class
map<string, section*> Class::getSections() {
    return sections;
}
