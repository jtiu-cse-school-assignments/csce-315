//
//  main.cpp
//  Individual Project
//This program keeps track of textbooks required and recommended for classes, as well of the cost of textbooks.

#include <iostream>
#include <map>
#include <utility>
#include <string>
#include <regex>
#include <vector>
#include "Class.h"
#include "Book.h"
using namespace std;

// Created functions to support each possible line format for standard input.
void createBook(string isbn, string title);
void createClass (string dept_code, string class_num, string class_name);
void defineChar (string isbn, string key, string value);
void definePrice(string isbn, string key, string value);
void assignBook (string isbn, string dept_code, string class_num, string section_num, string requirement);
void printClass(string dept_name, string class_num);
void printSection(string dept_name, string class_num, string section_num);
void printAllBooks();
void printAllClasses();
void printBookAfter(string month, string year);
void printDepartmentBooks(string dept_name);
void printDepartmentAvg(string dept_name);


//Functions to get the min & max price of books. Functions consist of a vector of a pair of strings.
double getMin(vector<pair<string, string> > books);
double getMax(vector<pair<string, string> > books);


//Created a map for books and classes which stores elements formed by a combination of a key value and a mapped value, following a specific order. Maps consist of a key value which are used to sort and identify elements, and a mapped value that store the content associated with the key.
map <string, Book*> books;                    //key: string (ISBN),  map:pointer reference to Book class
map <pair<string, string>, Class*> classes;   //key: pair of strings (dept.code & course num), map: pointer reference to Class


//Used regex to express patterns to be matched against sequence of characters for each possible entry.
int main ()
{
    string create_book ("(B) (\\d{13}) (.+)");
    string create_class ("(C) (\\w{4}) (\\d{3}) (.+)");
    string define_char ("(D) (\\d{13}) (((A) (.+))|((E) (\\d+))|((D) ((\\d{2})/(\\d{4}))))");
    string define_cost ("(M) (\\d{13}) (\\d*\\.\\d{2}) ([NURE])");
    string assign_book ("(A) (\\d{13}) (\\w{4}) (\\d{3}) (\\d{3}) ([OR])");
    string print_course_books ("(GC) (\\w{4}) (\\d{3})");
    string print_section_books ("(GS) (\\w{4}) (\\d{3}) (\\d{3})");
    string print_a_book ("(GB) (\\d{13})");
    string print_all ("(PB|PC)");
    string print_date ("(PY) ((\\d{2})/(\\d{4}))");
    string print_dept ("(PD) (\\w{4})");
    string print_avg ("(PM) (\\w{4})");
    

//Made a vector of strings that will store all entries.
    vector<string> patterns;
    patterns.push_back(create_book);
    patterns.push_back(create_class);
    patterns.push_back(define_char);
    patterns.push_back(define_cost);
    patterns.push_back(assign_book);
    patterns.push_back(print_course_books);
    patterns.push_back(print_section_books);
    patterns.push_back(print_a_book);
    patterns.push_back(print_all);
    patterns.push_back(print_date);
    patterns.push_back(print_dept);
    patterns.push_back(print_avg);
    
    int i = 0;
    string input;
    do{
        getline(cin,input);
        cout<<++i<<" "<<input<<endl;
        
        smatch args;
        for (int i = 0; i < patterns.size(); i++) {
            regex pattern (patterns[i]);
            
            if (regex_match(input, args, pattern))
                break;
        }
        if (args.size() == 0) {           //if no arguments matched, the user is asked to put in a valid command
            cout << "Invalid command" << endl;
            
            continue;
        }
        
        //Matches and states the user command as the first argument denoting the command letter
        string command = args[1];
        if (command == "B") {
            createBook(args[2], args[3]);                //i.e. args[2] = ISBN, args[3] = Title
        } else if (command == "C") {
            createClass(args[2], args[3], args[4]);
        } else if (command == "D") {                     //nested if-else statement for case D due to variables
            if (args[5] == "A") {
                defineChar(args[2], "author", args[6]);
            } else if (args[8] == "E") {
                defineChar(args[2], "edition", args[9]);
            } else if (args[11] == "D") {
                defineChar(args[2],"month" , args[13]);
                defineChar(args[2], "year", args[14]);
            }
        } else if (command == "M") {                    //nested if-else statement for case M due to variables
            string format;
            if (args[4] == "N") {
                format = "new";
            } else if (args[4] == "U") {
                format = "used";
            } else if (args[4] == "R") {
                format = "rented";
            } else if (args[4] == "E") {
                format = "electronic";
            }
            defineChar(args[2], format, args[3]);
            definePrice(args[2], format, args[3]);
        } else if (command == "A") {
            assignBook(args[2], args[3], args[4], args[5], args[6]);
        } else if (command == "GC") {
            printClass(args[2], args[3]);
        }else if (command == "GS") {
            printSection(args[2], args[3], args[4]);
        }else if (command == "GB") {
            cout << args[2] << ": ";
            books[args[2]]->print();
        }else if (command == "PB") {
            printAllBooks();
        }else if (command == "PC") {
            printAllClasses();
        }else if (command == "PY") {
            printBookAfter(args[2], args[3]);
        } else if (command == "PM") {
            printDepartmentAvg(args[2]);
        }
    } while (!cin.eof());
    
    return 1;
}

//Defining function for creating a Book with an ISBN and Title
void createBook(string isbn, string title) {
    Book* book = new Book();                    //new object pointer from Book class
    book->setInfo("title", title);              //reference to setInfo function to set the title of the book
    books[isbn] = book;                         //isbn will be matched in map of books which will equal book
}

//Defining function for creating Class with dept. code, class name, and class number
        //follows the same convention as createBook
void createClass(string dept_code, string class_num, string class_name) {
    Class* my_class = new Class();
    my_class->setName(class_name);
    classes[make_pair(dept_code, class_num)] = my_class;
}

//Function to define book's characteristics: ISBN, Key from map, and Value (price)
void defineChar(string isbn, string key, string value) {
    Book* book = books[isbn];                   //new object pointer from Book class equals isbn in books map
    book->setInfo(key, value);                  //reference to setInfo function will match key with value
}

//Function to define min and max prices of a book
void definePrice(string isbn, string key, string value) {
    Book* book = books[isbn];
    double price = stod(value);                 //price will be taken in as a string and converted to double
    double low = book->getLowestPrice();        //low equals the Book's lowest price
    double high = book->getHighestPrice();      //high equals the Book's highest price
    
    if (low == -1 || price < low) {             //set the book's lowest price
        book->setLowestPrice(price);
    }
    if (high == -1 || price > high) {
        book->setHighestPrice(price);
    }
}

//Function to assign book given ISBN, dept.code, class number, section number, and requirement (N,U,R,E)
void assignBook(string isbn, string dept_code, string class_num, string section_num, string requirement) {
    Class* my_class = classes[make_pair(dept_code,class_num)];  //object pointer from Class will be equal to the matched pair in map of classes
    my_class->assignBook(section_num, isbn, requirement);   //reference to assignBook function to set section num, ISBN, and requirement
}

//Function to print class
void printClass(string dept_name, string class_num) {
    Class* current_class = classes[make_pair(dept_name, class_num)];
    map<string, section*> class_sections = current_class->getSections();   //get a class' sections
    
//for loop iterates through the classes map
    for (map<string, section*>::iterator it = class_sections.begin(); it != class_sections.end(); ++it) {
        printSection(dept_name, class_num, it->first);  //
    }
}

//Function to print section
void printSection(string dept_name, string class_num, string section_num) {
    Class* current_class = classes[make_pair(dept_name,class_num)];
    cout << dept_name << " " << class_num << " " << section_num << ": "; //print dept name, class number, and section number
    vector<pair<string, string> > section_books = current_class->getBooks(section_num); //get a class' section's books
    
    for (pair<string, string> i : section_books) {   //print a section's books
        cout << i.first << ": ";
        books[i.first]->print();
        cout << i.second << endl;
    }
}

//Function to print all books
void printAllBooks() {
   //for loop iterates through map of books
    for (map<string, Book*>::iterator it = books.begin(); it != books.end(); ++it) {
        cout << it->first << ": ";
        it->second->print();
        cout << endl;
    }
}

//Function to print all classes
void printAllClasses() {
    //for loop iterates through map of classes
    for (map<pair<string, string>, Class*>::iterator it = classes.begin(); it != classes.end(); ++it) {
        printClass(it->first.first,it->first.second);
    }
}

//Function to print books according to date of publication
void printBookAfter(string month, string year) {
    for (map<string, Book*>::iterator it = books.begin(); it != books.end(); ++it) { //iterate through the maps of books
        string book_month = it->second->getInfo("month");
        string book_year = it->second->getInfo("year");
        
        int month_pub = stoi(book_month);       //month of publication converted from string to integer
        int year_pub = stoi(book_year);         //year of publication converted from string to integer
        
        if (book_month != "" && year_pub >= stoi(year) && month_pub >= stoi(month))
            it->second->print();
    }
}

//Function to print all books associated with a department
void printDepartmentBooks(string dept_name) {
    ////for loop iterates through map of classes
    for (map<pair<string, string>, Class*>::iterator it = classes.begin(); it != classes.end(); ++it) {
        string dept = it->first.first;
        string class_num = it->first.second;
        
        if (dept == dept_name) {
            printClass(dept, class_num);
        }
    }
}

//Function to calculate each department's average
void printDepartmentAvg(string dept_name) {
    double min = 0.0;
    double max = 0.0;
    int visited_sections = 0;
        //for loop iterates through map of classes
    for (map<pair<string, string>, Class*>::iterator it = classes.begin(); it != classes.end(); ++it) {
        string dept = it->first.first;          //stores dept
        if (dept == dept_name) {                //check to see if in right dept
            Class* class_object = it->second;   //stores the class
            map<string, section*> sections = class_object->getSections(); //gets a section of a class
            
     //iterating through a class's section
            for (map<string, section*>::iterator it2 = sections.begin(); it2 != sections.end(); ++it2) {
                bool valid_section = false;   //check to see if a section is valid (to be counted in avg or not)
                vector<pair<string, string> > section_books = it2->second->books;
                
                if (section_books.size() == 0)    //continue because nothing stored
                    continue;
                
                for (pair<string, string> book : section_books) {     //assign section's books
                    string isbn = book.first;
                    string requirement = book.second;
                    
                    Book* current_book = books[isbn];
                    if (requirement == "O") {                       //if the book is optional
                        double max_cost = current_book->getHighestPrice();   //get the highest price because only counting optional books in the highest
                        if (max_cost <= 0)
                            continue;
                        max += max_cost;                                    //max = max_cost + max
                        visited_sections += 1;
                        continue;
                    }
                    double min_cost = current_book->getLowestPrice();       //get lowest price
                    double max_cost = current_book->getHighestPrice();      //get highest price
                    
                    if (min_cost <= 0 && max_cost <= 0) {
                        continue;
                    }
                    min += min_cost;
                    max += max_cost;
                    valid_section = true;
                }
                if (valid_section)
                    visited_sections += 1;
            }
            
        }
    
    }
    double avg_min = min / visited_sections;                              //gets the average min cost
    double avg_max = max / visited_sections;                              //gets the average max cost
    
    cout << "Avg for " << dept_name << "-> min: " << avg_min << " max: " << avg_max << endl;
}
