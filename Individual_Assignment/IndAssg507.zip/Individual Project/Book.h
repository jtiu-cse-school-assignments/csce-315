//
//  Book.hpp
//  Individual Project
//

#ifndef Book_hpp
#define Book_hpp

#include <iostream>
#include <stdio.h>
#include <map>
#include <string>
using namespace std;

//defining the class, Book
class Book {
private:
    map<string, string> data;
    void printInfo(string key);
    double lowest_price = -1;
    double highest_price = -1;
public:                                                 
    Book();
    string getInfo(string key);
    void setInfo(string key, string val);
    void print();
    double getLowestPrice();
    void setLowestPrice(double price);
    double getHighestPrice();
    void setHighestPrice(double price);
};
#endif /* Book_hpp */
