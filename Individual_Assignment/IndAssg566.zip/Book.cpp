#include "Book.h"

using namespace std;

CBook::CBook(string strISBN, string sTitle) :
	m_sISBN(strISBN)
{
	m_sInfo.m_sTitle = sTitle;
	m_sInfo.m_sAuthor = "";
	m_sInfo.m_sPublicationDate = "";
	m_sInfo.m_sEdition = "";
	m_sInfo.m_fNewPrice = 00.00;
	m_sInfo.m_fUsedPrice = 00.00;
	m_sInfo.m_fRentedPrice = 00.00;
	m_sInfo.m_fElectronicPrice = 00.00;
	m_sInfo.m_bIsRequired = false;
}

CBook::CBook(std::string strISBN, std::string strAuthor = "", std::string strDate = "", std::string strEdition = "") :
	m_sISBN(strISBN)
{
	m_sInfo.m_sAuthor = strAuthor;
	m_sInfo.m_sPublicationDate = strDate;
	m_sInfo.m_sEdition = strEdition;
	m_sInfo.m_sTitle = "";
	m_sInfo.m_fNewPrice = 00.00;
	m_sInfo.m_fUsedPrice = 00.00;
	m_sInfo.m_fRentedPrice = 00.00;
	m_sInfo.m_fElectronicPrice = 00.00;
	m_sInfo.m_bIsRequired = false;
}

CBook::CBook(string strISBN, float NewPrice, float UsedPrice, float RentedPrice, float ElectronicPrice) :
	m_sISBN(strISBN)
{
	m_sInfo.m_fNewPrice = NewPrice;
	m_sInfo.m_fUsedPrice = UsedPrice;
	m_sInfo.m_fRentedPrice = RentedPrice;
	m_sInfo.m_fElectronicPrice = ElectronicPrice;
	m_sInfo.m_sTitle = "";
	m_sInfo.m_sAuthor = "";
	m_sInfo.m_sPublicationDate = "";
	m_sInfo.m_sEdition = "";
	m_sInfo.m_bIsRequired = false;
}


CBook::~CBook()
{
}