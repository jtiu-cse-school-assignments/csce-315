#include <iostream>
#include <string>
#include <algorithm>
#include "Book.h"
#include "Course.h"
#include "DataBaseMgr.h"

using namespace std;


int main() {

	CDataBaseMgr Manager;
	string commandStr;
	do {
		getline(cin, commandStr);
		commandStr.erase(remove(commandStr.begin(), commandStr.end(), '\r'), commandStr.end());
		cout << commandStr << endl;
		Manager.Input(commandStr);
	} while (!cin.eof());
	return 0;
}
