#pragma once
#include <map>
#include <string>
#include <vector>

class CCourse;
class CBook;
struct sSections;

enum eCommand
{
	INVALID, A_Command, B_Command,
	C_Command, D_Command, M_Command,
	GC_Command, GS_Command, GB_Command,
	PB_Command, PC_Command, PY_Command,
	PD_Command, PM_Command
};

class CDataBaseMgr
{
public:
	CDataBaseMgr();
	virtual ~CDataBaseMgr();

	// Main Parser and Input Handler
	void Input(std::string strInput);

	// Commands and controls
	void DefineBook			(std::string strISBN, std::string strTitle);
	void DefineBookInfo		(std::string strISBN, std::string cOption, std::string strValue);
	void DefineBookPrice	(std::string strISBN, std::string strPrice, std::string strFormat);
	void DefineCourse		(std::string strDepartment, std::string strCourse, std::string strCourseName);
	void AssignToClass		(std::string strISBN, std::string strDep, std::string strCourseNum, std::string strSection, std::string bIsRequired);

	// print funcitons
	void PrintAllBooks();
	void PrintAllCourses();
	void PrintByDate		(std::string strDate);
	void PrintByCourse		(std::string strDepartmnt, std::string strCourse);
	void PrintBySection		(std::string strDepartment, std::string strCourse, std::string strSectionNum);
	void PrintByDepartment	(std::string strDepartment);
	void PrintAvgCost		(std::string strDepartment);
	void PrintBook			(std::string strISBN);
	void PrintCourse		(CCourse Course);

	// Set/Get Controls
	CCourse* GetExistingCourse		( std::string strDepartmentCode, unsigned int nCourseNum);
	CBook* GetExistingBook			(const std::string& strISBN);
	sSections* GetExistingSection	(CCourse* Course, unsigned int nSection);

	// helpers
	void ConvertDate		(std::string Date, int& month, int& year);
	float MinCostOfSection	(sSections Section, int& nNumSectionsCounted);
	float MaxCostOfSection	(sSections Section, int& nNumSectionsCounted);
	std::vector<std::string> ParseCommand(std::string strInput);

private:
	std::map<std::string, eCommand> s_mapCommands;
	std::vector <CBook*> m_vecBooks;
	std::vector <CCourse*> m_vecCourses;
};

