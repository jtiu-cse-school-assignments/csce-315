#include <iostream>
#include <sstream>
#include <climits>
#include <float.h>
#include <iomanip>
#include "DataBaseMgr.h"
#include "Book.h"
#include "Course.h"


using namespace std;

CDataBaseMgr::CDataBaseMgr()
{
	// Create mapping for commands to simplify switch statements
	s_mapCommands["A"] = A_Command; s_mapCommands["B"] = B_Command; s_mapCommands["C"] = C_Command;
	s_mapCommands["D"] = D_Command; s_mapCommands["M"] = M_Command; s_mapCommands["GC"] = GC_Command;
	s_mapCommands["GS"] = GS_Command; s_mapCommands["GB"] = GB_Command; s_mapCommands["PB"] = PB_Command;
	s_mapCommands["PC"] = PC_Command; s_mapCommands["PY"] = PY_Command; s_mapCommands["PD"] = PD_Command;
	s_mapCommands["PM"] = PM_Command;

}


CDataBaseMgr::~CDataBaseMgr()
{
}


/////////////////////////
// Commands and Controls
/////////////////////////
void CDataBaseMgr::DefineBook( string strISBN, string strTitle )
{	
	if (strISBN.size() != 13)
	{
		cout << "Invalid ISBN" << endl;
		return;
	}

	// If the book doesnt exist already make a new one
	CBook* Book = GetExistingBook(strISBN);
	if (Book != NULL)
		Book->GetBookInfo().m_sTitle = strTitle;
	else
	{
		CBook* newBook = new CBook(strISBN, strTitle);
		m_vecBooks.push_back(newBook);
	}
}

void CDataBaseMgr::DefineBookInfo(string strISBN, string cOption, string strValue)
{
	if (strISBN.size() != 13)
	{
		cout << "Invalid ISBN" << endl;
		return;
	}

	bool bBookExists = false;
	CBook* Book = GetExistingBook(strISBN);
	if (Book != NULL)
	{
		bBookExists = true;
	}

	if (cOption == "A")
	{
		if (bBookExists)
			Book->GetBookInfo().m_sAuthor = strValue;
		else
		{
			CBook* newBook = new CBook(strISBN, strValue, "", "");
			m_vecBooks.push_back(newBook);
		}
	}
	else if (cOption == "E")
	{
		if (bBookExists)
			Book->GetBookInfo().m_sEdition = strValue;
		else
		{
			CBook* newBook = new CBook(strISBN, "", "", strValue);
			m_vecBooks.push_back(newBook);
		}
	}
	else if (cOption == "D")
	{
		if (bBookExists)
			Book->GetBookInfo().m_sPublicationDate = strValue;
		else
		{
			CBook* newBook = new CBook(strISBN, "", strValue, "");
			m_vecBooks.push_back(newBook);
		}
	}
	else
		cout << "Invalid Option" << endl;
	
}

void CDataBaseMgr::DefineBookPrice(string strISBN, string strPrice, string strFormat)
{
	// Look for valid Input
	if (strISBN.size() != 13 || strPrice.size() <= 4)
	{
		cout << "Invalid Command" << endl;
		return;
	}

	// Price Conversion and setup
	float fPrice = stof(strPrice);
	bool bBookExists = false;
	CBook* Book = GetExistingBook(strISBN);
	if (Book != NULL)
	{
		bBookExists = true;
	}


	// Check the book format and add the price
	if (strFormat == "N")
	{
		if (bBookExists)
			Book->GetBookInfo().m_fNewPrice = fPrice;
		else
		{
			CBook* newBook = new CBook(strISBN, fPrice, 00.00, 00.00, 00.00);
			m_vecBooks.push_back(newBook);
		}
	}
	else if (strFormat == "U")
	{
		if (bBookExists)
			Book->GetBookInfo().m_fUsedPrice = fPrice;
		else
		{
			CBook* newBook = new CBook(strISBN, 00.00, fPrice, 00.00, 00.00);
			m_vecBooks.push_back(newBook);
		}
	}
	else if (strFormat == "R")
	{
		if (bBookExists)
			Book->GetBookInfo().m_fRentedPrice = fPrice;
		else
		{
			CBook* newBook = new CBook(strISBN, 00.00, 00.00, fPrice, 00.00);
			m_vecBooks.push_back(newBook);
		}
	}
	else if (strFormat == "E")
	{
		if (bBookExists)
			Book->GetBookInfo().m_fElectronicPrice = fPrice;
		else
		{
			CBook* newBook = new CBook(strISBN, 00.00, 00.00, 00.00, fPrice);
			m_vecBooks.push_back(newBook);
		}
	}
	else
		cout << "Invalid Book Format" << endl;
	// Error

}

void CDataBaseMgr::DefineCourse(string strDepartment, string strCourse, string strCourseName)
{
	unsigned int nCourseNum = stoi(strCourse);
	// Department Codes must be 4 letters and Courses must be 3 digits
	if (strDepartment.size() != 4 || strCourse.size() != 3)
	{
		cout << "Invalid Course" << endl;
		return;
	}

	// If the course doesnt exist already make a new one
	CCourse* Course = GetExistingCourse(strDepartment, nCourseNum);
	if (Course != NULL)
		Course->SetCourseName(strCourseName);
	else
	{
		CCourse* newCourse = new CCourse(strDepartment, nCourseNum, strCourseName);
		m_vecCourses.push_back(newCourse);
	}
}

void CDataBaseMgr::AssignToClass(string strISBN, string strDepartment, string strCourseNum, string strSection, string strIsRequired)
{
	// Convert strings to the proper numbers
	unsigned int nCourseNum = stoi(strCourseNum);
	unsigned int nSection = stoi(strSection);
	bool bIsRequired = false;
	
	// Grab anything that exists
	CBook* Book = GetExistingBook(strISBN);
	CCourse* Course = GetExistingCourse(strDepartment, nCourseNum);
	sSections* Section = GetExistingSection(Course, nSection);

	if (Book == NULL || Course == NULL)
	{
		cout << "Class or Book does not exist" << endl;
		return;
	}

	if (Section == NULL) 
	{
		Course->AddSection(nSection);
		Section = GetExistingSection(Course, nSection);
	}
	if (strIsRequired == "R")
		bIsRequired = true;
	
	Section->m_vecAssignedBooks.push_back(*Book);
	Section->m_vecAssignedBooks.back().GetBookInfo().m_bIsRequired = bIsRequired;

}

////////////////////
// print funcitons
////////////////////
void CDataBaseMgr::PrintAllBooks()
{
	for (CBook* Book : m_vecBooks)
	{
		PrintBook(Book->GetISBN());
	}
}

void CDataBaseMgr::PrintAllCourses()
{
	for (CCourse* Course : m_vecCourses)
	{
		PrintCourse(*Course);
	}
}

void CDataBaseMgr::PrintByDate(string strDate)
{
	bool bMatchigBooks = false;
	int searchMonth; // value from input
	int searchYear; // value from input
	ConvertDate(strDate, searchMonth, searchYear);

	for (CBook* Book : m_vecBooks)
	{
		int BookPubMonth;// value from book
		int BookPubYear;// value from book
		ConvertDate(Book->GetBookInfo().m_sPublicationDate, BookPubMonth, BookPubYear);
		if (BookPubYear > searchYear || (BookPubMonth >= searchMonth && BookPubYear == searchYear)) // Print any matching or later dates
		{
			PrintBook(Book->GetISBN());
			bMatchigBooks = true;
		}
	}
	if (!bMatchigBooks)
		cout << "No books found that have a publication date of or later than " << strDate << endl;
}

void CDataBaseMgr::PrintByCourse(string strDepartmnt, string strCourse)
{
	// setup
	unsigned int nCourseNum = stoi(strCourse);
	CCourse* Course = GetExistingCourse(strDepartmnt, nCourseNum);
	string strRequired = "No";

	// Continue if we have an existing course
	if (Course)
	{
		for (sSections* Section : Course->GetAllSections())
		{
			cout << "Section: " << Section->m_nSectionNum << endl;

			for  (CBook Book : Section->m_vecAssignedBooks)
			{
				if (Book.GetBookInfo().m_bIsRequired)
					strRequired = "Yes";

				cout << "Is Required: " << strRequired << endl;
				PrintBook(Book.GetISBN());

				// reset our value
				strRequired = "No";
			}
		}
	}
}

void CDataBaseMgr::PrintBySection(string strDepartmnt, string strCourse, string strSection)
{
	// set up 
	unsigned int nCourseNum = stoi(strCourse);
	unsigned int nSection = stoi(strSection);
	CCourse* Course = GetExistingCourse(strDepartmnt, nCourseNum);
	sSections* Section = GetExistingSection(Course, nSection);
	string strRequired = "No";
	
	// Continue if we have an existing section
	if (Section)
	{
		for  (CBook Book : Section->m_vecAssignedBooks)
		{
			if (Book.GetBookInfo().m_bIsRequired)
				strRequired = "Yes";

			cout << "Is Required: " << strRequired << endl;
			PrintBook(Book.GetISBN());

			// reset our value
			strRequired = "No";
		}
	}
	else
		cout << "Invalid Section" << endl;
}

void CDataBaseMgr::PrintByDepartment(string strDepartment)
{
	for (CCourse* Course : m_vecCourses)
	{
		if (Course->GetDepartment() == strDepartment)
		{
			string course = to_string(Course->GetCourseNumber());
			cout << "Course Number: " << course << endl;
			PrintByCourse(strDepartment, course);
		}
	}
}

void CDataBaseMgr::PrintAvgCost(string strDepartment)
{
	// setup variables
	float fSumOfMin = 0;
	float fSumOfMax = 0;
	int nNumSectionMin = 0;
	int nNumSectionMax = 0;

	// get the sum cost for  section
	for (CCourse* Course : m_vecCourses)
	{
		if (Course->GetDepartment() == strDepartment)
		{
			for (sSections* Section : Course->GetAllSections())
			{
				fSumOfMin += MinCostOfSection(*Section, nNumSectionMin);
				fSumOfMax += MaxCostOfSection(*Section, nNumSectionMax);
			}
		}
	}

	// ensure we don't divide by zero
	if (nNumSectionMin != 0)
	{
		float fMinAvg = fSumOfMin / nNumSectionMin;
		cout << "The average minimum cost of books per a section across the " << fixed << setprecision(2) << strDepartment << " is: " << fMinAvg << endl;
	}

	if (nNumSectionMax != 0)
	{
		float fMaxAvg = fSumOfMax / nNumSectionMax;
		cout << "The average maximum cost of books per a section across the " << fixed << setprecision(2) << strDepartment << " is: " << fMaxAvg << endl;
	}
}

void CDataBaseMgr::PrintBook(string strISBN)
{
	CBook* Book = GetExistingBook(strISBN);
	if (Book != NULL)
	{
		cout << "ISBN: " << strISBN << endl;
		cout << "Title: " << Book->GetBookInfo().m_sTitle << endl;
		cout << "Author: " << Book->GetBookInfo().m_sAuthor << endl;
		cout << "Edition: " << Book->GetBookInfo().m_sEdition << endl;
		cout << "Publication: " << Book->GetBookInfo().m_sPublicationDate << endl;
		cout << "New: $" << Book->GetBookInfo().m_fNewPrice
			<< " Used: $" << Book->GetBookInfo().m_fUsedPrice
			<< " Rent: $" << Book->GetBookInfo().m_fRentedPrice
			<< " E-Book: $" << Book->GetBookInfo().m_fElectronicPrice << endl << endl;
	}
}

void CDataBaseMgr::PrintCourse(CCourse Course)
{
	cout << Course.GetDepartment() << " " << Course.GetCourseNumber() << endl;
	cout << "Sections : ";
	for (sSections* Section : Course.GetAllSections())
	{
		cout << Section->m_nSectionNum << "  ";
	}
	cout << endl;

}

//////////////////////
// Helper functions
//////////////////////
float CDataBaseMgr::MinCostOfSection(sSections Section, int& nNumSectionMin)
{
	// Gets the min cost of required books for the section, if no pricing returns 0
	float fCostOfSection = 0;
	for (CBook Book : Section.m_vecAssignedBooks)
	{
		sBookInfo Info = Book.GetBookInfo();
		if (Info.m_bIsRequired)
		{
			float fMinPrice = FLT_MAX;
			if(Info.m_fNewPrice < fMinPrice && Info.m_fNewPrice != 0)
				fMinPrice = Info.m_fNewPrice;

			if (Info.m_fUsedPrice < fMinPrice && Info.m_fUsedPrice != 0)
				fMinPrice = Info.m_fUsedPrice;

			if (Info.m_fRentedPrice < fMinPrice && Info.m_fRentedPrice != 0)
				fMinPrice = Info.m_fUsedPrice;

			if (Info.m_fElectronicPrice < fMinPrice && Info.m_fElectronicPrice != 0)
				fMinPrice = Info.m_fUsedPrice;

			if (fMinPrice != 0 && fMinPrice != FLT_MAX)
				fCostOfSection += fMinPrice;
		}
	}
	if (fCostOfSection != 0)
		++nNumSectionMin;

	return fCostOfSection;
}

float CDataBaseMgr::MaxCostOfSection(sSections Section, int& nNumSectionMax)
{
	// Gets the max cost of required books for the section, if no pricing returns 0
	float fCostOfSection = 0;
	for (CBook Book : Section.m_vecAssignedBooks)
	{
		sBookInfo Info = Book.GetBookInfo();
		float fMaxPrice = FLT_MIN;
		if (Info.m_fNewPrice > fMaxPrice && Info.m_fNewPrice != 0)
			fMaxPrice = Info.m_fNewPrice;

		if (Info.m_fUsedPrice > fMaxPrice && Info.m_fUsedPrice != 0)
			fMaxPrice = Info.m_fUsedPrice;

		if (Info.m_fRentedPrice > fMaxPrice && Info.m_fRentedPrice != 0)
			fMaxPrice = Info.m_fUsedPrice;

		if (Info.m_fElectronicPrice > fMaxPrice && Info.m_fElectronicPrice != 0)
			fMaxPrice = Info.m_fUsedPrice;

		if (fMaxPrice != 0 && fMaxPrice != FLT_MIN)
			fCostOfSection += fMaxPrice;
	}
	if (fCostOfSection != 0)
		++nNumSectionMax;

	return fCostOfSection;
}


// Converts the string date mm/yyyy into 2 ints for easy date checking
void CDataBaseMgr::ConvertDate(string Date, int& month, int& year)
{
	string strMonth = Date.substr(0, Date.find('/'));
	string strYear = Date.substr(Date.find('/') + 1);
	month = stoi(strMonth);
	year = stoi(strYear);
}

// Looks for existing courses in the DB
CCourse* CDataBaseMgr::GetExistingCourse(string strDepartmentCode, const unsigned int nCourseNum)
{
	for  (CCourse* Course : m_vecCourses)
	{
		if (Course->GetDepartment() == strDepartmentCode && Course->GetCourseNumber() == nCourseNum)
		{
			return Course;
		}
	}
	return NULL;
}

// Looks for existing books in the DB
CBook* CDataBaseMgr::GetExistingBook(const std::string& strISBN)
{
	for (CBook* Book : m_vecBooks)
	{
		if (Book->GetISBN() == strISBN)
		{
			return Book;
		}
	}
	return NULL;
}

// Looks for existing sections within an existing course
sSections* CDataBaseMgr::GetExistingSection(CCourse* Course, unsigned int nSectionNum)
{
	vector<sSections*> vecCourseSections = Course->GetAllSections();
	for (sSections* Section : vecCourseSections)
	{
		if (Section->m_nSectionNum == nSectionNum)
			return Section;
	}
	return NULL;
}

////////////////////////////////
// Command Parser and Dispatch
////////////////////////////////

// Takes the input from the input file and parses the commands
// Then dispatches it to the proper command function 
void CDataBaseMgr::Input(std::string strInput)
{
	vector<string> vecCommand = ParseCommand(strInput);
	switch (s_mapCommands[vecCommand.at(0)])
	{
		case A_Command:
		{
			if (vecCommand.size() == 6)
			{
				// in order of ISBN, Department, Course Number, Section, Required
				AssignToClass(vecCommand.at(1), vecCommand.at(2), vecCommand.at(3), vecCommand.at(4), vecCommand.at(5));
				break;
			}
		}
		case B_Command:
		{
			if (vecCommand.size() > 3) // protection from invalid input
			{
				string strTitle = "";
				for (int i = 2; i < vecCommand.size(); ++i)
				{
					strTitle = strTitle + " " + vecCommand.at(i);
				}
				DefineBook(vecCommand.at(1), strTitle);
				break;
			}
			else
				cout << "Invalid Command";
			break;
		}
		case C_Command:
		{
			if (vecCommand.size() >= 4) // prtection from invalid input
			{
				string strCourseName = "";
				for (int i = 3; i < vecCommand.size(); ++i)
				{
					strCourseName = strCourseName + " " + vecCommand.at(i);
				}
				// in order of Department, Course number, Course name
				DefineCourse(vecCommand.at(1), vecCommand.at(2), strCourseName);
			}
			break;
		}
		case D_Command:
		{
			if (vecCommand.size() == 4) // Protection from invalid input
			{
				// in order of ISBN, Option, Value
				DefineBookInfo(vecCommand.at(1), vecCommand.at(2), vecCommand.at(3));
				break;
			}
			else if (vecCommand.size() >= 4 && vecCommand.at(2) == "A") // Protection from invalid input/ handles Author input
			{
				string strAuthor = "";
				for (int i = 3; i < vecCommand.size(); ++i)
				{
					strAuthor = strAuthor + " " + vecCommand.at(i);
				}
				DefineBookInfo(vecCommand.at(1), "A", strAuthor);
			}
			else
				cout << "Invalid Command" << endl;
			break;
		}
		case M_Command:
		{
			if (vecCommand.size() == 4) // Protection from invalid input
			{
				// in order of ISBN, Price, Format of book
				DefineBookPrice(vecCommand.at(1), vecCommand.at(2), vecCommand.at(3));
			}
			else
				cout << "Invalid Commad" << endl;
			break;
		}
		case GC_Command:
		{
			if (vecCommand.size() == 3)
				// in order of Department, Course Number
				PrintByCourse(vecCommand.at(1), vecCommand.at(2));
			else
				cout << "Invalid Command" << endl;
			break;
		}
		case GS_Command:
		{
			if (vecCommand.size() == 4)
				// in order of Department, Course Number, Section Number
				PrintBySection(vecCommand.at(1), vecCommand.at(2), vecCommand.at(3)); 
			else
				cout << "Invalid Command" << endl;
			break;
		}
		case GB_Command:
		{
			if (vecCommand.size() == 2) // Protection from invalid input
				PrintBook(vecCommand.at(1));
			else
				cout << "Invalid Command" << endl;
			break;
		}
			break;
		case PB_Command:
		{
				PrintAllBooks();
			break;
		}
		case PC_Command:
		{
				PrintAllCourses();
			break;
		}
		case PY_Command:
		{
			if (vecCommand.size() == 2) // Protection from invalid input
				PrintByDate(vecCommand.at(1));
			else
				cout << "Invalid Command" << endl;
			break;
		}
		case PD_Command:
		{
			if (vecCommand.size() == 2) // Protection from invalid input
				PrintByDepartment(vecCommand.at(1));
			else
				cout << "Invalid Command" << endl;
			break;
		}
		case PM_Command:
		{
			cout << vecCommand.at(1) << endl;
			if (vecCommand.size() == 2) // Protection from invalid input
				PrintAvgCost(vecCommand.at(1));
			else
				cout << "Invalid Command" << endl;
			break;
		}
		case INVALID:
			cout << "No matching Command " << vecCommand.at(0) << endl;
			break;
		default:
			cout << "Error" << endl;
	}

}

// Simple parser to parse commands
vector<string> CDataBaseMgr::ParseCommand(string strInput)
{
	istringstream ss(strInput);
	string token;
	vector<string> ReturnVector;
	
	// parse out any spaces and return a vector of strings
	while (getline(ss, token, ' '))
	{
		ReturnVector.push_back(token);
	}
	return ReturnVector;
}