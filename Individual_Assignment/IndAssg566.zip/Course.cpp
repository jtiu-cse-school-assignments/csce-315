#include "Course.h"
using namespace std;

CCourse::CCourse(string strDepartment, unsigned int nCourse, string strCourseName) :
	m_strDepartmentCode(strDepartment), m_nCourseNum(nCourse), m_strCourseName(strCourseName)
{
}


CCourse::~CCourse()
{
}

void CCourse::AddSection(unsigned int nSectionNum)
{
	sSections* newSection = new sSections(nSectionNum);
	m_vecSections.push_back(newSection);
}

