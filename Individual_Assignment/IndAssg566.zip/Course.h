#pragma once
#include <string>
#include <vector>
#include "Book.h"

struct sSections
{
	sSections(unsigned int SectionNum) : m_nSectionNum(SectionNum) {}
	unsigned int m_nSectionNum;
	std::vector<CBook> m_vecAssignedBooks;
};

class CCourse
{
public:
	CCourse(std::string strDepartment, unsigned int nCourse, std::string strCourseName );
	virtual ~CCourse();

	std::string GetDepartment() { return m_strDepartmentCode; }
	std::vector<sSections*> GetAllSections() { return m_vecSections; }
	unsigned int GetCourseNumber() { return m_nCourseNum; }

	void SetCourseName(std::string strName) {m_strCourseName = strName;}
	void AddSection(unsigned int nSectionNum);

private:
	unsigned int m_nCourseNum;
	std::string m_strCourseName;
	std::string m_strDepartmentCode;
	std::vector<sSections*> m_vecSections;
};