#pragma once
#include <string>
#include <vector>


struct sBookInfo
{
	// general info
	std::string m_sTitle;
	std::string m_sAuthor;
	std::string m_sPublicationDate;
	std::string m_sEdition;

	// Prices
	float m_fNewPrice;
	float m_fUsedPrice;
	float m_fRentedPrice;
	float m_fElectronicPrice;
	bool m_bIsRequired;

};


class CBook
{
public: 
	CBook(std::string strISBN, std::string sTitle);
	CBook(std::string strISBN, std::string strAuthor, std::string strDate, std::string sEdition);
	CBook(std::string strISBN, float m_fNewPrice, float m_fUsedPrice, float m_fRentedPrice, float m_fElectronicPrice);
	virtual ~CBook();

	std::string GetISBN() { return m_sISBN; }
	
	sBookInfo& GetBookInfo() { return m_sInfo; }

private:
	std::string m_sISBN;
	sBookInfo m_sInfo;
};