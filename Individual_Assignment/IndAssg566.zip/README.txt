READ ME:
To compile use g++ -std=c++11 *.cpp
This is do to the use of range-based for loops